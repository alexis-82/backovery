#!/usr/bin/env pthon2
# -*- coding: utf-8 -*-
# Version Python 2.7.*

import os, sys, subprocess, time
from lib import Fore, Back, Style

subprocess.call("clear && clear", shell=True)

data = (time.strftime("%d_%m_%Y"))

print()
print((Fore.GREEN + "   ______    ____     ____  __   ___  ____   __    __   _____ ______ __      __ "))
print((Fore.GREEN + "  (_   _ \  (    )   / ___)() ) / __)/ __ \  ) )  ( (  / ___/(   __ \) \    / ( "))
print((Fore.GREEN + "    ) (_) ) / /\ \  / /    ( (_/ /  / /  \ \( (    ) )( (__   ) (__) )\ \  / /  "))
print((Fore.GREEN + "    \   _/ ( (__) )( (     ()   (  ( ()  () )\ \  / /  ) __) (    __/  \ \/ /   "))
print((Fore.GREEN + "    /  _ \  )    ( ( (     () /\ \ ( ()  () ) \ \/ /  ( (     ) \ \  _  \  /    "))
print((Fore.GREEN + "   _) (_) )/  /\  \ \ \___ ( (  \ \ \ \__/ /   \  /    \ \___( ( \ \_))  )(     "))
print((Fore.GREEN + "  (______//__(  )__\ \____)()_)  \_\ \____/     \/      \____\)_) \__/  /__\    "))
print((Fore.GREEN + "                                                                       remote   "))
print((Fore.RESET))
print((Fore.RED + "                                  Coded by Alexis                                 "))
print((Fore.RED + "                                https://alexis82.it/                              "))
print((Fore.RESET))
print()
print()
print()
print()
print()
filename = input("Digitare un nome per il salvataggio: ")
address= eval(input("Digitare la porta di ascolto: "))
command="nc -l -p %s > %s_%s.tgz"
print()
print()
print("Porta in ascolto e trasferimento in corso, attendere prego...")
os.system(command % (address, filename, data))
print()
print("Trasferimento terminato!")
print()
input("Premere un tasto per uscire")
os.system("clear && clear")
exit()